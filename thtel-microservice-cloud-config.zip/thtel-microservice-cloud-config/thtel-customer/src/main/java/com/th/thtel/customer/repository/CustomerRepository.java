package com.th.thtel.customer.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.th.thtel.customer.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

	

}
