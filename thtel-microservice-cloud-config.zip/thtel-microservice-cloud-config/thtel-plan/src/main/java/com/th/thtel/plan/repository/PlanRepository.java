package com.th.thtel.plan.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.th.thtel.plan.entity.Plan;

public interface PlanRepository extends JpaRepository<Plan, Integer> {
	
	List<Plan> findAll();
	

}
